﻿using Gaboy_Tic_Tac_Toe.Models;
using Microsoft.AspNetCore.Mvc;

namespace Gaboy_Tic_Tac_Toe.Controllers
{
    public class GameController : Controller
    {
        private static Gamemodel _game = new Gamemodel();

        public IActionResult Index()
        {
            // Load scores from session or initialize if not present
            ViewBag.PlayerXWins = HttpContext.Session.GetInt32("PlayerXWins") ?? 0;
            ViewBag.PlayerOWins = HttpContext.Session.GetInt32("PlayerOWins") ?? 0;
            ViewBag.Draws = HttpContext.Session.GetInt32("Draws") ?? 0;

            return View(_game);
        }

        public IActionResult MakeMove(int row, int col)
        {
            if (!_game.IsGameover && _game.Board[row, col] == ' ')
            {
                _game.MakeMove(row, col);

                // Check if the game is over and update scores
                if (_game.IsGameover)
                {
                    if (_game.Winner.Equals('X'))
                    {
                        int xWins = (HttpContext.Session.GetInt32("PlayerXWins") ?? 0) + 1;
                        HttpContext.Session.SetInt32("PlayerXWins", xWins);
                    }
                    else if (_game.Winner.Equals('O'))
                    {
                        int oWins = (HttpContext.Session.GetInt32("PlayerOWins") ?? 0) + 1;
                        HttpContext.Session.SetInt32("PlayerOWins", oWins);
                    }
                    else if (_game.Winner.Equals('D'))
                    {
                        int draws = (HttpContext.Session.GetInt32("Draws") ?? 0) + 1;
                        HttpContext.Session.SetInt32("Draws", draws);
                    }
                }
            }

            return RedirectToAction("Index");
        }

        public IActionResult Reset()
        {
            _game = new Gamemodel();
            return RedirectToAction("Index");
        }

        public IActionResult ResetScores()
        {
            // Reset scores stored in the session
            HttpContext.Session.SetInt32("PlayerXWins", 0);
            HttpContext.Session.SetInt32("PlayerOWins", 0);
            HttpContext.Session.SetInt32("Draws", 0);

            return RedirectToAction("Index");
        }
    }
}
