﻿namespace Gaboy_Tic_Tac_Toe.Models
{
    public class Gamemodel
    {
        public char[,] Board { get; private set; } = new char[3, 3];
        public char CurrentPlayer { get; private set; } = 'X';
        public bool IsGameover { get; private set; } = false;
        public char Winner { get; private set; } = ' ';

        // New: Player Names
        public string PlayerXName { get; set; } = "Player X";
        public string PlayerOName { get; set; } = "Player O";

        // Updated: Message includes player names
        public string Message
        {
            get
            {
                if (IsGameover)
                {
                    return Winner == 'D' ? "It's a draw!" : $"{(Winner == 'X' ? PlayerXName : PlayerOName)} wins!";
                }
                return $"{(CurrentPlayer == 'X' ? PlayerXName : PlayerOName)}'s turn!";
            }
        }

        // Constructor
        public Gamemodel()
        {
            // Initialize the board with empty spaces
            for (int i = 0; i < 3; i++)
                for (int j = 0; j < 3; j++)
                    Board[i, j] = ' ';
        }

        // Make a move on the board
        public void MakeMove(int row, int col)
        {
            if (IsGameover || Board[row, col] != ' ')
                return;

            Board[row, col] = CurrentPlayer;

            if (CheckWin(CurrentPlayer))
            {
                IsGameover = true;
                Winner = CurrentPlayer;
            }
            else if (CheckDraw())
            {
                IsGameover = true;
                Winner = 'D';  // D for Draw
            }
            else
            {
                // Switch players
                CurrentPlayer = (CurrentPlayer == 'X') ? 'O' : 'X';
            }
        }

        // Check for a win
        private bool CheckWin(char player)
        {
            // Check rows, columns, and diagonals
            for (int i = 0; i < 3; i++)
            {
                if ((Board[i, 0] == player && Board[i, 1] == player && Board[i, 2] == player) ||
                    (Board[0, i] == player && Board[1, i] == player && Board[2, i] == player))
                    return true;
            }
            if ((Board[0, 0] == player && Board[1, 1] == player && Board[2, 2] == player) ||
                (Board[0, 2] == player && Board[1, 1] == player && Board[2, 0] == player))
                return true;

            return false;
        }

        // Check for a draw
        private bool CheckDraw()
        {
            foreach (char cell in Board)
                if (cell == ' ')
                    return false;
            return true;
        }

        // Reset the game
        public void ResetGame()
        {
            for (int i = 0; i < 3; i++)
                for (int j = 0; j < 3; j++)
                    Board[i, j] = ' ';

            CurrentPlayer = 'X';
            IsGameover = false;
            Winner = ' ';
        }
    }
}
